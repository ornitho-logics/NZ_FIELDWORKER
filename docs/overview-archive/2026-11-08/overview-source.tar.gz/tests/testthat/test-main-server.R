test_that("main server initializes and updates the reference date", {
  app <- load_main_app()
  today <- as.Date(Sys.time(), tz = app$env$preferred_timezone)
  app$env$resolve_git_version <- function(...) {
    list(
      id = "67c8485",
      source = "remote:origin/main",
      local = FALSE,
      dirty = FALSE
    )
  }
  saved <- new.env(parent = emptyenv())
  saved$date <- as.Date(NA)
  saved$notices <- character()
  overview_calls <- new.env(parent = emptyenv())

  overview_plot_stub <- function(name) {
    force(name)
    overview_calls[[name]] <- as.Date(character())

    function(refdate, date_limits = NULL) {
      overview_calls[[name]] <- c(
        overview_calls[[name]],
        as.Date(refdate)
      )
      ggplot2::ggplot()
    }
  }

  app$env$get_reference_date <- function() today
  app$env$dbtable_is_updated <- function(...) "unchanged"
  app$env$set_reference_date <- function(refdate) {
    saved$date <- as.Date(refdate)
    TRUE
  }
  app$env$WarnToast <- function(message) {
    saved$notices <- c(saved$notices, as.character(message))
  }
  app$env$ErrToast <- function(...) NULL
  app$env$TABLE_show <- function(...) shiny::renderText("")
  app$env$later <- function(callback, delay = 0) callback()
  app$env$overview_date_limits <- function(refdate) {
    c(as.Date(refdate) - 30, as.Date(refdate))
  }
  app$env$overview_nests_graph <- overview_plot_stub("nests")
  app$env$overview_geolocator_graph <- overview_plot_stub("geolocator")
  app$env$overview_tagged_resightings_graph <- overview_plot_stub(
    "tagged_resightings"
  )
  app$env$overview_band_combos_graph <- overview_plot_stub("band_combos")
  app$env$overview_lay_date_graph <- overview_plot_stub("lay_date")
  app$env$overview_hatching_forecast_graph <- overview_plot_stub(
    "hatching_forecast"
  )
  app$env$overview_chick_growth_graph <- overview_plot_stub(
    "chick_growth"
  )
  app$env$overview_quota_graph <- overview_plot_stub("quota")

  shiny::testServer(app$server, {
    session$flushReact()

    output$overview_nests_show
    output$overview_geolocator_show
    output$overview_tagged_resightings_show
    output$overview_cr_combos_show
    output$overview_lay_date_show
    output$overview_hatching_forecast_show
    output$overview_chick_growth_show
    output$overview_quota_show

    expect_identical(as.Date(reference_date()), today)
    expect_identical(as.Date(active_refdate()), today)
    expect_identical(overview_calls$nests, today)
    expect_identical(overview_calls$geolocator, today)
    expect_identical(overview_calls$tagged_resightings, today)
    expect_identical(overview_calls$band_combos, today)
    expect_identical(overview_calls$lay_date, today)
    expect_identical(overview_calls$hatching_forecast, today)
    expect_identical(overview_calls$chick_growth, today)
    expect_identical(overview_calls$quota, today)
    expect_match(output$ref_date_text$html, as.character(today), fixed = TRUE)
    expect_match(output$open_gps$html, "../gpxui/", fixed = TRUE)
    expect_match(output$open_db$html, "db_ui/field_db.php", fixed = TRUE)
    expect_match(output$git_version_label$html, "67c8485", fixed = TRUE)
    expect_match(
      output$git_version_label$html,
      "https://github.com/ornitho-logics/NZ_FIELDWORKER/commit/67c8485",
      fixed = TRUE
    )

    next_date <- today + 1
    session$setInputs(refdate = as.character(next_date), set_refdate = 1)
    session$flushReact()

    expect_identical(saved$date, next_date)
    expect_identical(as.Date(reference_date()), next_date)
    expect_identical(tail(overview_calls$nests, 1), next_date)
    expect_identical(tail(overview_calls$geolocator, 1), next_date)
    expect_identical(
      tail(overview_calls$tagged_resightings, 1),
      next_date
    )
    expect_identical(tail(overview_calls$band_combos, 1), next_date)
    expect_identical(tail(overview_calls$lay_date, 1), next_date)
    expect_identical(
      tail(overview_calls$hatching_forecast, 1),
      next_date
    )
    expect_identical(tail(overview_calls$chick_growth, 1), next_date)
    expect_identical(tail(overview_calls$quota, 1), next_date)
    expect_true(any(grepl(
      as.character(next_date),
      saved$notices,
      fixed = TRUE
    )))
  })
})


test_that("overview graph helpers use aligned reference-date queries", {
  app <- load_main_app()
  refdate <- as.Date("2026-07-21")
  queries <- list()

  app$env$db_get <- function(sql, params) {
    queries[[length(queries) + 1]] <<- list(
      sql = sql,
      params = params
    )

    if (grepl("MIN(date_) AS start_date", sql, fixed = TRUE)) {
      return(data.frame(start_date = as.character(refdate - 30)))
    }

    if (grepl("SELECT COUNT", sql, fixed = TRUE)) {
      return(data.frame(n = 0))
    }

    data.frame()
  }

  date_limits <- app$env$overview_date_limits(refdate)

  expect_equal(date_limits, c(refdate - 30, refdate))
  expect_s3_class(
    app$env$overview_nests_graph(refdate, date_limits),
    "ggplot"
  )
  expect_s3_class(
    app$env$overview_geolocator_graph(refdate, date_limits),
    "ggplot"
  )
  expect_s3_class(
    app$env$overview_tagged_resightings_graph(refdate, date_limits),
    "ggplot"
  )
  expect_s3_class(
    app$env$overview_band_combos_graph(refdate, date_limits),
    "ggplot"
  )
  expect_s3_class(
    app$env$overview_lay_date_graph(refdate, date_limits),
    "ggplot"
  )
  expect_s3_class(
    app$env$overview_chick_growth_graph(refdate),
    "patchwork"
  )

  grDevices::pdf(NULL)
  on.exit(grDevices::dev.off(), add = TRUE)
  quota_plots <- app$env$overview_quota_graph(refdate)
  expect_s3_class(
    app$env$overview_hatching_forecast_graph(refdate),
    "ggplot"
  )

  expect_length(quota_plots, 4)
  expect_length(queries, 13)
  expect_true(all(vapply(
    queries,
    function(query) identical(query$params, list(as.character(refdate))),
    logical(1)
  )))

  geolocator_quota_sql <- queries[[which(vapply(
    queries,
    function(query) grepl(
      "COUNT(DISTINCT NULLIF(TRIM(tag_id)",
      query$sql,
      fixed = TRUE
    ),
    logical(1)
  ))[1]]]$sql

  expect_match(
    geolocator_quota_sql,
    "COUNT(DISTINCT NULLIF(TRIM(tag_id), ''))",
    fixed = TRUE
  )

  band_capture_sql <- queries[[which(vapply(
    queries,
    function(query) grepl("c.UL_in", query$sql, fixed = TRUE),
    logical(1)
  ))[1]]]$sql
  band_resighting_sql <- queries[[which(vapply(
    queries,
    function(query) grepl("r.age", query$sql, fixed = TRUE) &&
      grepl("r.UL", query$sql, fixed = TRUE),
    logical(1)
  ))[1]]]$sql

  expect_match(band_capture_sql, "c.age", fixed = TRUE)
  expect_match(band_capture_sql, "c.site", fixed = TRUE)
  expect_match(band_capture_sql, "sr.reference_date", fixed = TRUE)
  expect_match(band_resighting_sql, "r.age", fixed = TRUE)
  expect_match(band_resighting_sql, "r.site", fixed = TRUE)
  expect_match(band_resighting_sql, "r.UL", fixed = TRUE)
  expect_false(grepl("r.ring", band_resighting_sql, fixed = TRUE))

  hatching_index <- which(vapply(
    queries,
    function(query) grepl(
      "e.predicted_hatch_date > sr.reference_date",
      query$sql,
      fixed = TRUE
    ),
    logical(1)
  ))
  expect_length(hatching_index, 1L)
  expect_match(
    queries[[hatching_index]]$sql,
    "FROM EGGS_HATCH_PREDICTION e",
    fixed = TRUE
  )
})


test_that("chick growth plot uses ring-only identity and has three panels", {
  app <- load_main_app()
  x <- data.frame(
    ring = c(
      "MOCK_RING_A", "MOCK_RING_A", "MOCK_RING_B", "MOCK_RING_B",
      "MOCK_RING_C", "MOCK_RING_C"
    ),
    nest_id = c(
      "MOCK_NEST_1", "MOCK_NEST_1", "MOCK_NEST_1", "MOCK_NEST_1",
      "MOCK_NEST_2", "MOCK_NEST_2"
    ),
    age_days = c(0, 5, 0, 5, 0, 5),
    age_class = rep("C", 6),
    weight = c(8, 12, 7, 11, 9, 13),
    culmen = c(7, 10, 7.2, 10.2, 7.5, 10.5),
    tarsus = c(19, 22, 19.2, 22.2, 19.5, 22.5)
  )
  x <- rbind(
    x,
    data.frame(
      ring = c("MOCK_RING_ADULT_A", "MOCK_RING_ADULT_B"),
      nest_id = NA_character_,
      age_days = NA_real_,
      age_class = "A",
      weight = c(42, 44),
      culmen = c(32, 33),
      tarsus = c(48, 49)
    )
  )

  plot <- app$env$overview_chick_growth_plot(
    x,
    refdate = as.Date("2026-10-19")
  )

  expect_s3_class(plot, "patchwork")
  expect_equal(
    plot$patches$plots[[1]]$scales$get_scales("y")$limits,
    c(7, 13)
  )
})


test_that("chick growth query is reference-date bounded and ring filtered", {
  app <- load_main_app()
  refdate <- as.Date("2026-07-21")
  query <- NULL

  app$env$db_get <- function(sql, params) {
    query <<- list(sql = sql, params = params)
    data.frame()
  }

  expect_s3_class(
    app$env$overview_chick_growth_graph(refdate),
    "patchwork"
  )
  expect_equal(query$params, list(as.character(refdate)))
  expect_match(query$sql, "COALESCE(c.age, '')", fixed = TRUE)
  expect_match(query$sql, ") = 'C'", fixed = TRUE)
  expect_match(query$sql, "TRIM(c.ring)", fixed = TRUE)
  expect_match(query$sql, "c.date <= sr.reference_date", fixed = TRUE)
  expect_match(query$sql, "FROM NESTS n", fixed = TRUE)
  expect_match(query$sql, "'A' AS age_class", fixed = TRUE)
  expect_match(query$sql, "365 AS age_days", fixed = TRUE)
  expect_match(query$sql, "UNION ALL", fixed = TRUE)
})


test_that("band-combo overview reconciles adult identities and exposes safe diagnostics", {
  app <- load_main_app()

  captures <- data.frame(
    pk = 1:4,
    date = as.Date(c(
      "2026-08-01", "2026-08-02", "2026-08-03", "2026-08-04"
    )),
    age = "A",
    site = "CR",
    ring = c(
      "MOCK_RING_F",
      "MOCK_RING_M",
      "MOCK_RING_FLAG",
      "MOCK_RING_SPACER"
    ),
    UL = c("W", "B", "FW74-X", "BY"),
    LL = c("Y", "Y", "B", "BY"),
    UR = c("G", "Y", NA, "TY"),
    LR = c("O", "B", "O", "G"),
    UL_in = NA_character_,
    LL_in = NA_character_,
    UR_in = NA_character_,
    LR_in = NA_character_,
    field_sex = c("F", "M", "F", "F")
  )

  resightings <- data.frame(
    pk = 101:106,
    date = as.Date(c(
      "2026-08-05", "2026-08-06", "2026-08-07",
      "2026-08-08", "2026-08-09", "2026-08-10"
    )),
    age = "A",
    site = "CR",
    UL = c(NA, NA, "FW74-X", NA, "Y", NA),
    LL = c("Y", "Y", "B", "BY", "O", "O"),
    UR = c(NA, NA, NA, NA, "O", NA),
    LR = c("O", "B", "O", "YG", "G", "G"),
    sex = c("F", "M", "F", "F", "F", "F")
  )

  reconciled <- app$env$overview_band_combo_reconcile_identities(
    captures = captures,
    resightings = resightings
  )
  summary <- reconciled$summary

  expect_equal(nrow(summary), 5L)
  summary_counts <- app$env$overview_band_combo_summary_counts(summary)
  female_counts <- summary_counts[summary_counts$sex == "Female", ]
  male_counts <- summary_counts[summary_counts$sex == "Male", ]
  expect_equal(female_counts$total, 4L)
  expect_equal(female_counts$captured, 3L)
  expect_equal(female_counts$resighted_only, 1L)
  expect_equal(
    female_counts$captured + female_counts$resighted_only,
    female_counts$total
  )
  expect_equal(male_counts$total, 1L)
  expect_equal(male_counts$captured, 1L)
  expect_equal(male_counts$resighted_only, 0L)
  expect_equal(
    app$env$overview_band_combo_summary_label(summary),
    paste(
      "N females = 4 (3 caps, 1 res)",
      "N males = 1 (1 caps, 0 res)",
      sep = "\n"
    )
  )
  expect_equal(
    sum(summary$has_capture == 1L & summary$has_resighting == 1L),
    4L
  )
  expect_equal(
    sum(summary$has_capture == 0L & summary$has_resighting == 1L),
    1L
  )
  expect_equal(reconciled$ambiguous_resighting_events, 0L)

  flag_identity <- summary[
    identity_key == "ring:MOCK_RING_FLAG"
  ]
  spacer_identity <- summary[
    identity_key == "ring:MOCK_RING_SPACER"
  ]
  expect_equal(flag_identity$has_resighting, 1L)
  expect_equal(spacer_identity$has_resighting, 1L)

  lower_duplicate <- summary[
    identity_key %in% c("ring:MOCK_RING_F", "ring:MOCK_RING_M")
  ]
  expect_equal(
    lower_duplicate$has_resighting,
    c(1L, 1L)
  )

  capture_resighting <- reconciled$resightings[
    !is.na(matched_ring),
    .(matched_ring, match_method)
  ]
  expect_setequal(
    capture_resighting$matched_ring,
    c(
      "MOCK_RING_F",
      "MOCK_RING_M",
      "MOCK_RING_FLAG",
      "MOCK_RING_SPACER"
    )
  )
  expect_true(any(capture_resighting$match_method == "flag"))
  expect_true(any(capture_resighting$match_method == "spacer"))

  # The final row is a resighting-only identity with a full mark followed by
  # a lower-only representation. Both must count once.
  expect_equal(
    sum(summary$n_normalized_representations > 1L),
    3L
  )

  app$env$db_get <- function(sql, params) {
    if (grepl("AS source_table", sql, fixed = TRUE)) {
      return(data.frame(
        source_table = c(
          "CAPTURES", "CAPTURES", "RESIGHTINGS", "RESIGHTINGS"
        ),
        age_key = c("A", "J", "A", "J"),
        n_rows = c(10L, 2L, 10L, 2L)
      ))
    }
    if (grepl("c.UL_in", sql, fixed = TRUE)) {
      return(captures)
    }
    if (grepl("r.UL", sql, fixed = TRUE)) {
      return(resightings)
    }
    data.frame()
  }

  plot <- app$env$overview_band_combos_graph(
    refdate = as.Date("2026-08-31")
  )
  expect_s3_class(plot, "ggplot")

  diagnostic <- app$env$overview_band_combo_diagnostic(
    refdate = as.Date("2026-08-31")
  )
  expect_equal(diagnostic$adult_event_rows, 20L)
  expect_equal(diagnostic$non_adult_event_rows, 4L)
  expect_equal(diagnostic$unique_adult_identities, 5L)
  expect_equal(diagnostic$capture_and_resighting_identities, 4L)
  expect_equal(diagnostic$resighting_only_identities, 1L)
  expect_equal(diagnostic$ambiguous_resighting_events, 0L)

  empty_reconciled <- app$env$overview_band_combo_reconcile_identities(
    captures = data.frame(),
    resightings = data.frame()
  )
  expect_equal(nrow(empty_reconciled$summary), 0L)
  expect_true(is.na(app$env$overview_band_combo_normalize_value(
    "X-X",
    remove_hyphen = TRUE
  )))
})



test_that("pair tally does not fall back to the obsolete heuristic", {
  app <- load_main_app()
  calls <- 0L

  app$env$db_get <- function(sql, params) {
    calls <<- calls + 1L

    if (grepl("identity_match", sql, fixed = TRUE)) {
      return(data.frame(error = "mock database does not support the extended pair query"))
    }

    data.frame(n_unconfirmed_pairs = 17L)
  }

  expect_error(
    app$env$overview_pair_tallies(
      refdate = as.Date("2026-07-21"),
      require_geolocator = TRUE
    ),
    "mock database does not support the extended pair query"
  )
  expect_equal(calls, 1L)
})


test_that("pair protocol helper is separate from sex-only panels", {
  app <- load_main_app()
  refdate <- as.Date("2026-07-21")

  app$env$db_get <- function(sql, params) {
    if (grepl("MIN(date_) AS start_date", sql, fixed = TRUE)) {
      return(data.frame(start_date = as.character(refdate - 30)))
    }

    if (
      grepl("parent_events AS", sql, fixed = TRUE) &&
        grepl("m.has_geolocator = 1", sql, fixed = TRUE)
    ) {
      return(data.frame(n_unconfirmed_pairs = 17L))
    }

    if (grepl("parent_events AS", sql, fixed = TRUE)) {
      return(data.frame(n_unconfirmed_pairs = 17L))
    }

    data.frame()
  }

  expect_equal(
    app$env$overview_pair_tallies(refdate, require_geolocator = TRUE),
    c(unconfirmed_pairs = 17L)
  )
  expect_equal(
    app$env$overview_pair_tallies(refdate, require_geolocator = FALSE),
    c(unconfirmed_pairs = 17L)
  )

  geolocator_plot <- app$env$overview_geolocator_graph(refdate)
  band_combos_plot <- app$env$overview_band_combos_graph(refdate)
  caption <- app$env$overview_pair_confirmation_caption()

  expect_null(geolocator_plot$labels$caption)
  expect_null(band_combos_plot$labels$caption)
  expect_match(caption, "caught with the nest trap", fixed = TRUE)
  expect_match(caption, "resighted around the nest 3 times", fixed = TRUE)
  expect_match(caption, "behav class \"IN\", \"NM\", \"BW\", \"BC\", \"FC\", or \"AC\"", fixed = TRUE)
})


test_that("lay-date bins tally geolocators by associated nest", {
  app <- load_main_app()
  x <- data.frame(
    nest_id = c("MOCK_NEST_1", "MOCK_NEST_1", "MOCK_NEST_2", "MOCK_NEST_3"),
    datetime = as.Date(c(
      "2026-09-01",
      "2026-09-01",
      "2026-09-01",
      "2026-09-05"
    )),
    tag_id = c("MOCK_GEO_1", "MOCK_GEO_1", "MOCK_GEO_2", NA_character_)
  )

  bins <- app$env$overview_lay_date_bins(x, binwidth = 4L)

  expect_equal(sum(bins$n_nests), 3L)
  expect_equal(sum(bins$n_geolocators), 2L)
  expect_equal(bins$n_nests, c(2L, 1L))
  expect_equal(bins$n_geolocators, c(2L, 0L))

  plot <- app$env$overview_lay_date_plot(
    x,
    ylab = "N estimated lay dates",
    date_limits = as.Date(c("2026-08-25", "2026-09-10"))
  )

  expect_s3_class(plot, "ggplot")
  expect_silent(ggplot2::ggplot_build(plot))
  label_index <- which(vapply(
    plot$layers,
    function(layer) inherits(layer$geom, "GeomLabel"),
    logical(1)
  ))
  expect_length(label_index, 1L)
  label_layer <- plot$layers[[label_index]]
  expect_equal(label_layer$aes_params$hjust, 0)
  expect_equal(label_layer$aes_params$vjust, 1.05)
  expect_equal(
    label_layer$aes_params$label,
    paste(
      "Numbers above bars = geolocators deployed",
      "on parents associated with nests",
      "in each 4-day lay-date bin",
      sep = "\n"
    )
  )
})


test_that("hatching forecast uses one-day bins, three-day labels, and marks reference date", {
  app <- load_main_app()
  refdate <- as.Date("2026-09-01")
  x <- data.frame(
    nest_id = c("MOCK_NEST_1", "MOCK_NEST_2", "MOCK_NEST_3"),
    datetime = as.POSIXct(
      c("2026-08-31 00:00:00", "2026-09-03 00:00:00", "2026-09-10 00:00:00"),
      tz = "UTC"
    )
  )

  plot <- app$env$overview_hatching_forecast_plot(x, refdate)

  expect_s3_class(plot, "ggplot")
  built <- NULL
  expect_silent(built <- ggplot2::ggplot_build(plot))
  expect_equal(
    plot$coordinates$limits$x,
    as.Date(c("2026-08-29", "2026-09-10"))
  )
  histogram_index <- which(vapply(
    plot$layers,
    function(layer) inherits(layer$geom, "GeomBar"),
    logical(1)
  ))
  expect_length(histogram_index, 1L)
  expect_equal(plot$layers[[histogram_index]]$stat_params$binwidth, 1)
  vline_index <- which(vapply(
    plot$layers,
    function(layer) inherits(layer$geom, "GeomVline"),
    logical(1)
  ))
  expect_length(vline_index, 1L)
  expect_gt(vline_index, histogram_index)
  reference_label <- vapply(
    plot$layers,
    function(layer) {
      identical(layer$aes_params$label, "reference date") &&
        identical(layer$aes_params$angle, 90)
    },
    logical(1)
  )
  expect_true(any(reference_label))
  x_breaks <- built$layout$panel_params[[1]]$x$breaks
  x_breaks <- x_breaks[is.finite(x_breaks)]
  expect_equal(diff(x_breaks), rep(3, length(x_breaks) - 1L))
})


test_that("overview limp status distinguishes comment evidence", {
  app <- load_main_app()
  comments <- c(
    "walking normally",
    "slight hesitation while walking",
    "bird is limping",
    "foraging beside the river",
    "walks fine and limps",
    "walks well, no limp",
    "not limping today",
    "limp0",
    "limp: 1",
    "LIMP = 2"
  )

  expect_identical(
    app$env$overview_limp_status(comments),
    c(
      "No limp reported",
      "Possible/slight limp",
      "Limping",
      "No limp reported",
      "Limping",
      "No limp reported",
      "No limp reported",
      "No limp reported",
      "Possible/slight limp",
      "Limping"
    )
  )
  expect_identical(
    app$env$overview_tagged_mark_label(c("WY_GO_F", "BY_L_M")),
    c("WY-GO", "BY-L")
  )
  expect_identical(
    app$env$overview_tagged_display_mark(
      c("BY_L", "BY_L", "WY_GO"),
      c("TY", "TG", "TO"),
      c("L", "L", "GO")
    ),
    c("BY_Y.L", "BY_G.L", "WY_GO")
  )
  expect_identical(
    app$env$overview_deployment_linetype(c("C", "F", NA_character_)),
    c("dashed", "solid", "solid")
  )

  mock_histories <- data.frame(
    tarsus_mark = c("MOCK_A", "MOCK_A", "MOCK_B"),
    right_upper = c("TY", "TY", "TG"),
    right_tarsus = c("A", "A", "B"),
    sex = c("Female", "Female", "Male"),
    deployment_capture_status = c("C", "C", "F"),
    deployment_date = as.Date(c(
      "2026-09-01",
      "2026-09-01",
      "2026-09-03"
    )),
    resighting_pk = c(1L, 2L, 3L),
    resighting_date = as.Date(c(
      "2026-09-04",
      "2026-09-06",
      "2026-09-07"
    )),
    comments = c(
      "walking normally",
      "slight hesitation while walking",
      "bird is limping"
    )
  )
  plot <- app$env$overview_tagged_resighting_plot(
    mock_histories,
    date_limits = as.Date(c("2026-09-01", "2026-09-10"))
  )

  expect_s3_class(plot, "ggplot")
  expect_silent(ggplot2::ggplot_build(plot))
  expect_equal(
    plot$coordinates$limits$x,
    as.Date(c("2026-08-30", "2026-09-10"))
  )
  expect_s3_class(plot$facet, "FacetGrid")
  expect_true(plot$facet$params$free$y)
  expect_true(plot$facet$params$space_free$y)
  expect_setequal(
    plot$data$deployment_linetype,
    c("dashed", "solid")
  )
  expect_s3_class(plot$theme$strip.text.y, "element_blank")
  expect_match(plot$labels$caption, "\n", fixed = TRUE)
  expect_match(plot$labels$caption, "capture_status = C", fixed = TRUE)
  expect_identical(plot$guides$guides$fill$params$ncol, 1)
  expect_identical(
    plot$theme$legend.title.position,
    "top"
  )
  expect_identical(plot$theme$legend.direction, "vertical")
  facet_annotation_data <- Filter(
    function(layer_data) "facet_label" %in% names(layer_data),
    lapply(plot$layers, function(layer) layer$data)
  )
  expect_length(facet_annotation_data, 1)
  expect_setequal(
    facet_annotation_data[[1]]$facet_label,
    c("Females", "Males")
  )

  shared_mark_plot <- app$env$overview_tagged_resighting_plot(
    data.frame(
      tarsus_mark = c("BY_YB", "BY_YB"),
      right_upper = c("TY", "TG"),
      right_tarsus = c("YB", "YB"),
      sex = c("Female", "Male"),
      deployment_capture_status = c("C", "F"),
      deployment_date = as.Date(c("2026-09-02", "2026-09-03")),
      resighting_pk = c(11L, 12L),
      resighting_date = as.Date(c("2026-09-06", "2026-09-07")),
      comments = c("walking normally", "walking normally")
    ),
    date_limits = as.Date(c("2026-09-01", "2026-09-10"))
  )

  expect_setequal(
    as.character(shared_mark_plot$data$bird_id),
    c("BY_YB_F", "BY_YB_M")
  )
  expect_setequal(
    as.character(shared_mark_plot$data$sex),
    c("Female", "Male")
  )
})


test_that("overview cumulative ribbons contain no diagonal segments", {
  app <- load_main_app()
  x <- data.table::data.table(
    plot_date = as.Date(c("2026-08-01", "2026-08-03", "2026-08-07")),
    cumulative_n = c(1L, 3L, 4L)
  )

  ribbon <- app$env$overview_step_ribbon_data(x)
  x_change <- diff(as.numeric(ribbon$plot_date))
  y_change <- diff(ribbon$cumulative_n)

  expect_true(all(x_change == 0 | y_change == 0))

  sex_counts <- data.table::data.table(
    plot_date = as.Date(c(
      "2026-08-01",
      "2026-08-03",
      "2026-08-02",
      "2026-08-07"
    )),
    sex = c("Female", "Female", "Male", "Male"),
    cumulative_n = c(1L, 2L, 1L, 2L)
  )
  plot <- app$env$overview_cumulative_plot(
    sex_counts,
    ylab = "Cumulative count",
    sex_split = TRUE,
    date_limits = as.Date(c("2026-08-01", "2026-08-10")),
    summary_label = "Number of females = 2\nNumber of males = 2"
  )

  expect_silent(ggplot2::ggplot_build(plot))
  expect_identical(plot$theme$legend.position, "inside")
  expect_equal(plot$theme$legend.position.inside, c(0.02, 0.76))
  expect_equal(
    plot$coordinates$limits$x,
    as.Date(c("2026-08-01", "2026-08-10"))
  )
  annotation_labels <- unlist(lapply(plot$layers, function(layer) {
    if (!is.null(layer$aes_params$label)) {
      return(as.character(layer$aes_params$label))
    }

    character()
  }))

  expect_contains(
    annotation_labels,
    "Number of females = 2\nNumber of males = 2"
  )
  annotation_layer <- plot$layers[[which(vapply(
    plot$layers,
    function(layer) !is.null(layer$aes_params$label),
    logical(1)
  ))]]
  expect_equal(annotation_layer$aes_params$vjust, 1.3)
  expect_identical(
    app$env$overview_cumulative_total(sex_counts, "Female"),
    2L
  )
})
