test_results <- read.csv("../tests/test-results.csv")
tests_ok <- test_results$failed[1] == 0

app_test_status <- list(
  text = glue::glue("{test_results$passed[1]} tests passed"),
  badge = glue::glue("{test_results$failed[1]} failed"),
  badge_color = if (tests_ok) "success" else "danger",
  icon = if (tests_ok) "circle-check" else "circle-xmark",
  icon_color = if (tests_ok) "#00815f" else "#d70427"
)

dashboardPage(
  scrollToTop = TRUE,
  dark = NULL,
  freshTheme = fieldworker_theme,
  fullscreen = TRUE,
  help = NULL,
  preloader = list(
    html = spin_loaders(id = 16, color = "#3480be"),
    color = "#f8fafc"
  ),

  # The sidebar version label is resolved per Shiny session. Keep the browser
  # title stable so a process-start value cannot make the app look stale.
  title = "FIELDWORKER",

  header = dashboardHeader(
    title = dashboardBrand(
      title = HTML(
        '
        <span style="font-family: Georgia, serif; font-size: 1em; font-weight: 700;">
          B<span style="font-size: 1.3em;">&#8857;</span>2026
        </span>
        '
      ),
      image = "ICO.png"
    ),
    uiOutput("ref_date_text"),
    skin = "light",
    status = "white"
  ),

  sidebar = dashboardSidebar(
    collapsed = TRUE,
    width = "180px",
    skin = "light",
    status = "primary",
    sidebarMenu(
      id = "main", # Assigning an id here allows input$main to be set
      menuItem(
        "Field Resightings",
        tabName = "field_resightings",
        icon = icon("magnifying-glass")
      ),
      menuItem("Downloads", tabName = "downloads", icon = icon("download")),
      menuItem("Intro", tabName = "intro", icon = icon("circle-info")),
      menuItem("Overview", tabName = "overview", icon = icon("circle-play")),
      menuItem("GPS", tabName = "gps", icon = icon("location-arrow")),
      menuItem("Enter Data", tabName = "enter_data", icon = icon("edit")),
      menuItem("Show tables", tabName = "show_tables", icon = icon("table")),
      menuItem("Show Views", tabName = "show_views", icon = icon("eye")),
      menuItem("Database", tabName = "database", icon = icon("database")),
      menuItem(
        "Nest Map",
        tabName = "nest_map",
        icon = icon("broadcast-tower")
      ),
      menuItem(
        "Field Manual",
        tabName = "field_manual",
        icon = icon("book-open")
      ),

      hr(),

      menuItem(
        text = uiOutput("git_version_label", inline = TRUE),
        icon = icon("code-branch", style = "color: gray;")
      ),
      menuItem(
        text = app_test_status$text,
        icon = icon(
          app_test_status$icon,
          style = glue("color: {app_test_status$icon_color};")
        ),
        badgeLabel = app_test_status$badge,
        badgeColor = app_test_status$badge_color
      )
    )
  ),

  controlbar = dashboardControlbar(
    width = 280,
    overlay = FALSE,
    collapsed = TRUE,
    skin = "light",

    bs4Dash::box(
      title = "Fieldwork datetime",
      width = 12,
      overlay = FALSE,
      collapsible = FALSE,
      tags$div(
        class = "preferred-timezone-clock",
        `data-timezone` = preferred_timezone,
        tags$div(
          class = "preferred-timezone-name",
          preferred_timezone
        ),
        tags$div(
          class = "preferred-timezone-value",
          "--"
        )
      )
    ),

    bs4Dash::box(
      title = "Reference date",
      width = 12,
      overlay = FALSE,
      collapsible = FALSE,
      dateInput(
        inputId = 'refdate',
        label = NULL,
        value = NULL
      ),
      actionButton(
        inputId = "set_refdate",
        label = "Set",
        icon = icon("check"),
        class = "btn-primary refdate-set-button"
      )
    ),

    bs4Dash::box(
      title = "Map settings",
      width = 12,
      sliderInput(
        inputId = "nest_size",
        label = "Text and symbol size:",
        min = 3,
        max = 12,
        step = 0.5,
        value = 4
      ),

      pickerInput(
        inputId = "nest_state",
        label = "State / brood:",
        multiple = TRUE,
        choices = c(
          "Scrape" = "S",
          "Found" = "F",
          "Incubated" = "I",
          "Brood" = "brood",
          "possibly Predated" = "pP",
          "possibly Deserted" = "pD",
          "Predated" = "P",
          "Deserted" = "D",
          "Not Active" = "notA",
          "Other" = "O"
        ),
        selected = c("S", "F", "I", "brood", "pP", "pD", "P", "D", "notA", "O")
      )
    )
  ),
  body = dashboardBody(
    tags$head(
      tags$link(rel = "manifest", href = "manifest.webmanifest"),
      tags$meta(name = "theme-color", content = "#2f6fa3"),
      tags$meta(name = "mobile-web-app-capable", content = "yes"),
      tags$meta(name = "apple-mobile-web-app-capable", content = "yes"),
      tags$meta(name = "apple-mobile-web-app-title", content = "Fieldworker"),
      tags$link(rel = "apple-touch-icon", href = "icons/icon-192.png")
    ),
    includeCSS("./www/style.css"),
    includeScript("./www/reference_date.js"),
    includeScript("./www/download_feedback.js"),
    includeScript("./www/live_nest_leaflet.js"),
    includeScript("./www/field_resightings_location.js"),
    includeScript("./www/pwa_install.js"),

    tabItems(
      # Download tab
      tabItem(
        tabName = "downloads",
        bs4Dash::box(
          title = "Install and downloads",
          width = 11,
          collapsible = FALSE,

          tags$button(
            id = "install_mobile",
            type = "button",
            class = "btn btn-success btn-lg btn-block mb-3",
            icon("mobile-alt"),
            "Install app on this device"
          ),
          tags$p(
            class = "small text-muted mb-2",
            "Downloaded files are saved by the browser or installed app. ",
            "On Android or iPhone/iPad, open the Files app and check Downloads or Recent."
          ),
          tags$p(
            id = "download_location_notice",
            class = "small font-weight-bold mb-3 d-none",
            "Download started. After it finishes, push Open or check Downloads or Recent in the Files app."
          ),
          actionButton(
            inputId = "refresh_todo_snapshot",
            label = tagList(
              icon("database"),
              "Build To-do snapshot"
            ),
            class = "btn btn-secondary btn-lg btn-block field-download-button"
          ),
          tags$p(
            id = "todo_snapshot_build_time",
            class = "small text-muted mt-2 mb-2",
            "Can take up to 20 minutes to build; a busy server may take longer. ",
            "Please do not start another build while one is running."
          ),
          uiOutput("todo_snapshot_status"),
          br(),
          downloadLink(
            outputId = "todo_pdf",
            label = tagList(icon("file-pdf"), "Download To-do PDF"),
            class = "btn btn-primary btn-lg btn-block field-download-button"
          ),
          br(),
          downloadLink(
            outputId = "nest_latest_kmz",
            label = tagList(icon("globe"), "Download Offline Nest KMZ"),
            class = "btn btn-primary btn-lg btn-block field-download-button"
          ),
          br(),
          downloadLink(
            outputId = "tables_html",
            label = tagList(
              icon("table"),
              "Download Offline Interactive Tables"
            ),
            class = "btn btn-primary btn-lg btn-block field-download-button"
          ),
          br(),
          downloadLink(
            outputId = "database_rds",
            label = tagList(icon("database"), "Download Database as RDS"),
            class = "btn btn-warning btn-lg btn-block field-download-button"
          ),
          br(),
          downloadLink(
            outputId = "database_copy",
            label = tagList(icon("database"), "Download Database Copy"),
            class = "btn btn-warning btn-lg btn-block field-download-button"
          ),
          br()
        )
      ),

      # Intro tab
      tabItem(
        tabName = "intro",
        bs4Card(
          title = "Fieldworker at a glance",
          width = 12,
          collapsible = FALSE,

          includeHTML("./www/help/intro.html")
        )
      ),

      # Overview tab
      tabItem(
        tabName = "overview",
        bs4Dash::box(
          title = "Current quotas for manipulations (Cass and elsewhere in NZ).",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "40vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_quota_show",
              height = "32vh"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: lay date phenology",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "50vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_lay_date_show"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: Hatching Forecast",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "50vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_hatching_forecast_show"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: Seasonal progression in nest discovery",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "50vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_nests_show"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: Seasonal progression in unique band combinations encountered (resighted or captured)",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "50vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_cr_combos_show"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: Seasonal progression in geolocator deployments",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "50vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_geolocator_show"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: Chick growth trends",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          height = "55vh",
          style = "overflow: hidden;",
          spinner(
            plotOutput(
              "overview_chick_growth_show",
              height = "47vh"
            )
          )
        ),
        bs4Dash::box(
          title = "Cass: Resighting histories of geolocator-tagged birds",
          width = 12,
          collapsible = TRUE,
          collapsed = FALSE,
          spinner(
            plotOutput(
              "overview_tagged_resightings_show",
              height = "105vh"
            )
          )
        )
      ),

      # Field Resightings tab
      tabItem(
        tabName = "field_resightings",
        bs4Dash::box(
          title = "Field Resightings",
          width = 12,
          collapsible = FALSE,
          tags$form(
            class = "field-resightings-form",
            onsubmit = paste0(
              "Shiny.setInputValue('field_resightings_request', ",
              "{combo: document.getElementById('field_resightings_combo').value}, ",
              "{priority: 'event'}); return false;"
            ),
            tags$div(
              class = "form-group shiny-input-container",
              style = "width: 100%;",
              tags$input(
                id = "field_resightings_combo",
                type = "text",
                class = "form-control",
                placeholder = "COMBO (LLLR e.g. OYRL)",
                autocapitalize = "characters",
                autocorrect = "off",
                autocomplete = "off",
                spellcheck = "false",
                enterkeyhint = "search"
              )
            ),
            tags$button(
              id = "field_resightings_submit",
              type = "submit",
              class = "btn btn-primary btn-lg btn-block",
              icon("magnifying-glass"),
              "Search"
            )
          ),
          spinner(uiOutput("field_resightings_results"))
        )
      ),

      # GPS tab
      tabItem(
        tabName = "gps",
        uiOutput("open_gps"),
        hr(),
        includeHTML("./www/help/gps.html")
      ),

      # Enter Data tab
      tabItem(
        tabName = "enter_data",
        uiOutput("new_data"),
        hr(),
        includeHTML("./www/help/enter_data.html")
      ),

      # DB tab
      tabItem(
        tabName = "database",
        uiOutput("open_db"),
        includeHTML("./www/help/database.html")
      ),

      # Show tables tab
      tabItem(
        tabName = "show_tables",
        bs4Dash::tabsetPanel(
          id = "tabset_tables",
          .list = lapply(dbtabs_show_tables, function(i) {
            tabPanel(
              title = glue("[{i}]"),
              active = FALSE,
              spinner(
                DTOutput(outputId = glue("{i}_show"))
              )
            )
          })
        )
      ),

      # Show views tab
      tabItem(
        tabName = "show_views",
        bs4Dash::tabsetPanel(
          id = "tabset_views",
          .list = lapply(dbtabs_show_views, function(i) {
            tabPanel(
              title = glue("[{i}]"),
              active = FALSE,
              if (identical(i, "notA_summary")) {
                tags$p(
                  class = "small text-muted",
                  "Historical notA nests and both parents, from the latest successful To-do snapshot. ",
                  "Rebuild after records or the reference date change. A notA nest may still have a live brood. ",
                  "Later nests require a confirmed individual match; pending observations are shown separately. ",
                  "If no rows appear, check that a current snapshot is ready and DATABASE/notA_summary.SQL is installed."
                )
              },
              spinner(
                DTOutput(outputId = glue("{i}_show"))
              )
            )
          })
        )
      ),

      # Live Nest Map tab
      tabItem(
        tabName = "nest_map",
        fluidRow(
          bs4Dash::box(
            width = 12,
            collapsible = FALSE,
            maximizable = TRUE,

            spinner(
              leafletOutput(
                outputId = "nest_map_show",
                width = "100%",
                height = "calc(99vh - 1px)"
              )
            )
          )
        )
      ),

      # Static, database-independent manual; styles and search stay in its frame.
      tabItem(
        tabName = "field_manual",
        tags$p(
          class = "small text-muted mb-2",
          tags$a(
            href = "field-manual/core-guide.html",
            target = "_blank",
            rel = "noopener",
            "Open Field Manual in a separate window"
          )
        ),
        tags$iframe(
          id = "field_manual_reader",
          title = "BADO Field Manual — Core Team Field Guide and Full Protocol Manual",
          src = "field-manual/core-guide.html",
          loading = "lazy",
          style = paste0(
            "width:100%;height:calc(100vh - 145px);min-height:600px;",
            "border:0;border-radius:0.85rem;background:white;"
          )
        )
      )
    )
  )
)
